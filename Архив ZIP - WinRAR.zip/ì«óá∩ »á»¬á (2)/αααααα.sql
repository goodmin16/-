USE [master]
GO

/****** Object:  Database [Тур Агенства]    Script Date: 06.02.2023 22:32:00 ******/
DROP DATABASE [Тур Агенства]
GO

