select * from DOGOVOR where SUMMA > 70000
