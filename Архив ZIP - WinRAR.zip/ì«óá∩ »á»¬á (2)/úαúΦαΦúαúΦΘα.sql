USE [master]
GO

/****** Object:  Database [Тур Агенства]    Script Date: 02.02.2023 21:51:28 ******/
DROP DATABASE [Тур Агенства]
GO

