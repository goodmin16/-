delete from DOGOVOR where ID_KLIENTA= 3
select * from DOGOVOR