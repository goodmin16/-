delete DOGOVOR where ID_KLIENTA = 4
select * from PRODAJI